from django.apps import AppConfig


class WwwConfig(AppConfig):
    name = 'www'
